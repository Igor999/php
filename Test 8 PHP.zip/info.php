<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
<?php
session_start();
    // создаем новую сессию или 
    // восстанавливаем текущую

// Открываем БД
// константы
$server='localhost';
$db = 'trade1';
$table = 'users';
$user = 'root';
$pass = '1';

// соединение
$conn = mysql_connect($server, $user, $pass) or die("Не удалось установить соединение");

// установить кодировку БД
mysql_set_charset('utf8',$conn) or die('Не удалось установить кодировку utf8');

// выбрать базу данных
mysql_select_db($db,$conn) or die("Не удалось открыть БД $db");

$login = $_SESSION["login"];
$password = $_SESSION["password"];

// выполнение запроса (3)
$sql = "select * from users where login='$login' and password='$password'";
$zapros = mysql_query($sql,$conn) or die("Не удалось выполнить запрос $sql");

// перенаправление на разные страницы в зависимости от результата запроса
    $rows = mysql_num_rows($zapros);
    mysql_close($conn);
    
    if ($rows == 1) {
       $_SESSION["correct"] = 1; // для предотвращения прямого вызова формы
       header("Location: form.php"); // переход на форму ввода данных (правильная авторизация)
}
    else
       header("Location: index.php"); // переход на форму авторизации (неправильная авторизация) 
?>
    </body>
</html>             
