<?php
// Сохранение переменных в Cookies.
// Длительность хранения - неделя

session_start();
if (!$_SESSION["correct"] == 1) return; // для предотвращения прямого вызова скрипта

$week = time() + 24*60*60*7;

setcookie('film',$_POST['film'],$week);
setcookie('regis',$_POST['regis'],$week);


if (isset($_POST['actors'])) {
    $actors = serialize($_POST['actors']);
    setcookie('actors',$actors,$week);
}

setcookie('zhanr',$_POST['zhanr'],$week);

header("Location:form.php");

?>
