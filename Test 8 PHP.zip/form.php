<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Пример (вариант 10)</title>
    </head>
    <body>
  <?php
session_start();
if (!$_SESSION["correct"] == 1) return; // для предотвращения прямого вызова формы

  ?>
        
  <form action="save.php" method="POST">      
  Наименование фильма <br><input type=text name="film" value="<?=setText('film')?>"><br>
  Режиссер <br><input type=text name="regis" value="<?=setText('regis')?>"><br>
  
  Актеры <br>
<select name="actors[]" multiple size=4>
	<option value="Анджелина Джоли" <?=selActor("Анджелина Джоли")?>>Анджелина Джоли
	<option value="Брэд Питт" <?=selActor("Брэд Питт")?>>Брэд Питт
	<option value="Брюс Уиллис" <?=selActor("Брюс Уиллис")?>>Брюс Уиллис
	<option value="Ума Турман" <?=selActor("Ума Турман")?>>Ума Турман
</select>
<br>
<select name="zhanr" >
	<option value="Жанр" <?=selZhanr("Жанр")?>>Жанр
	<option value="Мелодрама" <?=selZhanr("Мелодрама")?>>Мелодрама
	<option value="Триллер" <?=selZhanr("Триллер")?>>Триллер
	<option value="Боевик"  <?=selZhanr("Боевик")?>>Боевик
</select>

<input type=submit value="Отправить">

  </form>        

  
  <!--  Функции  -->
  <?php
 
  function setText($name) {
      
     if (!isset($_COOKIE["$name"])) 
         return "";
     else
         return $_COOKIE["$name"]; 
  }
  
  
  function selZhanr($value) {
     if (!isset($_COOKIE["zhanr"]))
         $sel = "Жанр";
     else
         $sel = $_COOKIE["zhanr"];
         
     if ($sel == $value) return "selected"; else return "";
      
  }
  
  
  function selActor($value) {

// распаковать массив актеров
if (isset($_COOKIE['actors'])) $actors = unserialize($_COOKIE['actors']);
else $actors = array();
      
      if (in_array($value,$actors))
              return "selected";
      else
              return ""; 
      
  }
  
  ?>
        
    </body>
</html>
