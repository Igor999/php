<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <div>
<?php
session_start();
    // создаем новую сессию или 
    // восстанавливаем текущую
if (!isset($_GET['go'])) // если кнопка не нажата
{
?>
  <form>
    Логин: <input type=text name=login><br>
    Пароль: <input type=password name=password><br>
    <input type=submit name=go value=Вход><br>
  </form>

<?php  
}
else // кнопка нажата
{
    $_SESSION["login"] = $_GET["login"];
    $_SESSION["password"] = $_GET["password"];
    
        header("Location: info.php");

}    
?>
        </div>
    </body>
</html>              