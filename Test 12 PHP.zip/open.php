
<?php

// константы
$server='localhost';
$db = 'trade1';
$user = 'root';
$pass = '1';

// соединение
$conn = mysql_connect($server, $user, $pass) or die("Не удалось установить соединение");

// установить кодировку БД
mysql_set_charset('utf8',$conn) or die('Не удалось установить кодировку utf8');

// выбрать базу данных
mysql_select_db($db,$conn) or die("Не удалось открыть БД $db");;


?>

