-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 23 2014 г., 15:30
-- Версия сервера: 5.5.35
-- Версия PHP: 5.3.10-1ubuntu3.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `trade1`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cinema`
--

CREATE TABLE IF NOT EXISTS `cinema` (
  `id_cinema` int(11) NOT NULL AUTO_INCREMENT,
  `id_movie` int(11) NOT NULL,
  `cinema` varchar(20) NOT NULL,
  `show_date` date NOT NULL,
  PRIMARY KEY (`id_cinema`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `cinema`
--

INSERT INTO `cinema` (`id_cinema`, `id_movie`, `cinema`, `show_date`) VALUES
(1, 4, 'Победа 3', '2015-04-09'),
(2, 4, 'Октябрь', '2014-03-27'),
(3, 5, 'Победа', '2010-01-21'),
(4, 4, 'Октябрь', '2014-05-23'),
(5, 6, 'Победа', '2014-09-23');

-- --------------------------------------------------------

--
-- Структура таблицы `movie`
--

CREATE TABLE IF NOT EXISTS `movie` (
  `id_movie` int(11) NOT NULL AUTO_INCREMENT,
  `regis` varchar(50) NOT NULL,
  `actor` varchar(50) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `title` varchar(80) NOT NULL,
  PRIMARY KEY (`id_movie`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `movie`
--

INSERT INTO `movie` (`id_movie`, `regis`, `actor`, `genre`, `title`) VALUES
(4, 'реж', 'акт', 'жан', 'назв4'),
(5, 'реж2', 'акт2', 'жан2', 'назв2'),
(6, 'реж5', 'акт5', 'жан5', 'назв5');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
