<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
<?php
session_start();
    if (isset($_POST['movie'])) {
        $_SESSION = $_POST;
        header("Location:movie.php"); // переходим к добавлению/изменению данных фильмов
    }
    
    if (isset($_POST['cinema'])) {
        $_SESSION = $_POST;
        header("Location:cinema.php"); // переходим к списку показа отмеченного фильма
    }
 ?>       
        
<!-- Выводит список фильмов с возможностью
добавления нового фильма и выбора конкретного фильма для
просмотра кинотеатров и дат просмотра -->

<form method="POST">
<table>
<?php

include 'open.php'; // открываем БД

// получаем из БД список фильмов
$sql = "SELECT * FROM movie";
$result = mysql_query($sql,$conn) or die("Не удалось выполнить запрос");

$num_rows = mysql_num_rows($result); // сколько фильмов в БД

// выводим список фильмов из БД в таблицу
while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
    $id_movie = $row['id_movie'];
    $regis = $row['regis'];
    $actor = $row['actor'];
    $title = $row['title'];
    $genre = $row['genre'];
    
    echo "<tr>";
    echo "<td><input type='hidden' name='id_movie[]' value='$id_movie'></td>";
    echo "<td><input type='text' name='title[]' value='$title'></td>";
    echo "<td><input type='text' name='regis[]' value='$regis'></td>";
    echo "<td><input type='text' name='genre[]' value='$genre'></td>";
    echo "<td><input type='text' name='actor[]' value='$actor'></td>";
    echo "<td><input type='radio' name='radio' value='$id_movie'></td>";
    echo "</tr>";
}
mysql_close($conn);

// добавляем пустую строку к таблице для вставки нового фильма
    $id_movie = 0;
    $regis = "";
    $actor = "";
    $title = "";
    $genre = "";    
    echo "<tr>";
    echo "<td><input type='hidden' name='id_movie[]' value='$id_movie'></td>";
    echo "<td><input type='text' name='title[]' value='$title'></td>";
    echo "<td><input type='text' name='regis[]' value='$regis'></td>";
    echo "<td><input type='text' name='genre[]' value='$genre'></td>";
    echo "<td><input type='text' name='actor[]' value='$actor'></td>";

    echo "</tr>";
?>
</table>
    <input type="submit" name="movie" value="Добавить/Изменить">
    <input type="submit" name="cinema" value="Кинотеатр">
</form>        
    </body>
</html>          
