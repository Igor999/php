<?php
session_start();
include 'open.php'; // открываем БД

// Изменение и возможное добавление фильмов
    $id_movie = $_SESSION['id_movie'];
    $actor = $_SESSION['actor'];
    $title = $_SESSION['title'];
    $genre = $_SESSION['genre'];
    $regis = $_SESSION['regis'];
// Изменение
    for($i=0;$i<count($id_movie)-1;$i++) {
        $id_movie_upd = $id_movie[$i];
        $actor_upd = $actor[$i];
        $title_upd = $title[$i];
        $genre_upd = $genre[$i];
        $regis_upd = $regis[$i];        
        $sql = "UPDATE movie SET title='$title_upd',actor='$actor_upd',genre='$genre_upd',regis='$regis_upd' WHERE id_movie=$id_movie_upd";
        mysql_query($sql,$conn) or die('Ошибка в запросе UPDATE');
    }
    
 // Добавление
 $i=count($id_movie)-1;  
 $actor_ins = $actor[$i];
 $title_ins = $title[$i];
 $genre_ins = $genre[$i];
 $regis_ins = $regis[$i];
 
 if (!empty($actor_ins) || !empty($title_ins) || !empty($genre_ins) || !empty($regis_ins)) {
    $sql = "INSERT INTO movie (title,actor,regis,genre) VALUES ('$title_ins','$actor_ins','$regis_ins','$genre_ins')"; 
    mysql_query($sql,$conn) or die('Ошибка в запросе INSERT');
 }
mysql_close($conn);
header("Location:index.php");

?>

