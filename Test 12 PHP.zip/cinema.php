<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
<?php
session_start();

    if (isset($_POST['home'])) {
        header("Location:index.php"); // возврат к главной странице
    }



    if (isset($_POST['cinema_add'])) {
        $radio = $_SESSION['radio'];
        $_SESSION = $_POST;
        $_SESSION['radio'] = $radio;
        header("Location:cinema_add"); // переходим к добавлению/изменению данных кинотеатров
    }
    
    // если кнопки не нажаты, значит,  вызов из формы списка фильмов
    // проверяем, была ли нажата радиокнопка
    if (!isset($_SESSION['radio'])) {
        header("Location:index.php"); // возврат к главной странице
    }    
    
 ?>       
        
<!-- Выводит список  кинотеатров и дат просмотра 
для данного фильма -->

<form method="POST">
<table>
<?php

include 'open.php'; // открываем БД

// получаем из БД список кинотеатров для данного фильма
$id_movie = $_SESSION['radio'];
$sql = "SELECT * FROM cinema WHERE id_movie=$id_movie";
$result = mysql_query($sql,$conn) or die("Не удалось выполнить запрос");

$num_rows = mysql_num_rows($result); // сколько записей в БД

// выводим список кинотеатров из БД в таблицу
while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
    $id_cinema = $row['id_cinema'];
    $cinema = $row['cinema'];
    // переводим дату формата MySQL в массив
    $arr_date = explode('-',$row['show_date']);
    // затем - в unix-дату
    $unixtime = mktime(0,0,0,$arr_date[1],$arr_date[2],$arr_date[0]);
    // и в строку нужного формата функцией date
    $show_date = date("d-m-Y",$unixtime);
    
    echo "<tr>";
    echo "<td><input type='hidden' name='id_movie[]' value='$id_movie'></td>";
    echo "<td><input type='hidden' name='id_cinema[]' value='$id_cinema'></td>";
    echo "<td><input type='text' name='cinema[]' value='$cinema'></td>";
    echo "<td><input type='text' name='show_date[]' value='$show_date'></td>";
    echo "</tr>";
}
mysql_close($conn);

// добавляем пустую строку к таблице для вставки нового кинотеатра
    $id_cinema = 0;
    $cinema = "";
    $show_date = "";
  
    echo "<tr>";
    echo "<td><input type='hidden' name='id_movie[]' value='$id_movie'></td>";
    echo "<td><input type='hidden' name='id_cinema[]' value='$id_cinema'></td>";
    echo "<td><input type='text' name='cinema[]' value='$cinema'></td>";
    echo "<td><input type='text' name='show_date[]' value='$show_date'></td>";
    echo "</tr>";
?>
</table>
    <input type="submit" name="cinema_add" value="Добавить/Изменить">
    <input type="submit" name="home" value="Назад">
</form>        
    </body>
</html>          


