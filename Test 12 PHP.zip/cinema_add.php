<?php
session_start();
include 'open.php'; // открываем БД

// Изменение и возможное добавление кинотеатров
    $id_cinema = $_SESSION['id_cinema'];
    $id_movie = $_SESSION['id_movie'];
    $cinema = $_SESSION['cinema'];
    $show_date = $_SESSION['show_date'];

// Изменение
    for($i=0;$i<count($id_cinema)-1;$i++) {
        $id_cinema_upd = $id_cinema[$i];
        $cinema_upd = $cinema[$i];
        
        $arr_date = explode('-',$show_date[$i]); // переводим строку даты в массив
        $unixtime = mktime(0,0,0,$arr_date[1],$arr_date[0],$arr_date[2]);
        $show_date_upd = date('Y-m-d',$unixtime); // дата в формате MYSQL
        
        $sql = "UPDATE cinema SET cinema='$cinema_upd',show_date='$show_date_upd' WHERE id_cinema=$id_cinema_upd";
        mysql_query($sql,$conn) or die('Ошибка в запросе UPDATE');
    }
    
 // Добавление
 $i=count($id_cinema)-1;  

 
 if (!empty($show_date[$i])) {
    $id_movie_ins = $id_movie[$i];
    $cinema_ins = $cinema[$i];
    $arr_date = explode('-',$show_date[$i]); // переводим строку даты в массив
    $unixtime = mktime(0,0,0,$arr_date[1],$arr_date[0],$arr_date[2]);
    $show_date_ins = date('Y-m-d',$unixtime); // дата в формате MYSQL     
    $sql = "INSERT INTO cinema (id_movie,cinema,show_date) VALUES ('$id_movie_ins','$cinema_ins','$show_date_ins')"; 
    mysql_query($sql,$conn) or die('Ошибка в запросе INSERT');
 }
mysql_close($conn);
header("Location:cinema.php");

?>


